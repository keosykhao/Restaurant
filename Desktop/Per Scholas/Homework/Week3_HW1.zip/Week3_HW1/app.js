// colors array
var i = 0;
var colors = ['aquamarine', 'bisque', 'red', 'purple'];
document.querySelector("grid").addEventListener('click',
function(){
   for ( let i =0, i < colors.length, ++i){
    document.querySelector(".grid").style.color = colors [i]{
        
    }
})

// make a timer

var timer = document.getElementsById('#grid-1');
[].forEach.call(timer,function(x) {
    var currentTime = 0,
    interval = 0,
    lastUpdateTime = new Date().getTime(),
    start = s.querySelector('button.start'),
    mins = s.querySelector('span.minutes'),
    secs = s.querySelector('span.seconds');

    function pad (n){
        return 
    }
    
})




